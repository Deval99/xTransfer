package com.xtransfer;



import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import javafx.application.Platform;
import javafx.scene.control.*;

class TestClass implements Runnable{
    double total;
    ProgressBar pb;
    TestClass(double total, ProgressBar pb){
        this.total = total;
        this.pb = pb;
    }
    @Override
    public void run() {
        pb.setProgress((total/(double)100));
    }
    
}
public class FileSender
{   
    ProgressBar progressBar;
    class ThreadMake implements Runnable{
        Thread thread;
        String ip;
        String filePath;
        Label statusLabel;
        ProgressBar pb;
        ThreadMake(String i, String f, Label s, ProgressBar p){
            pb=p;
            statusLabel = s;
            filePath = f;
            ip = i;
            thread = new Thread(this);
            thread.start();
        }
        @Override
        public void run() {
            FileSender nioClient = new FileSender();
            SocketChannel socketChannel = nioClient.createChannel(ip, statusLabel);
            nioClient.sendFile(socketChannel, filePath, statusLabel, pb);
        }
    }    
    void send(String ip, String filePath, Label statusLabel, ProgressBar pb){
            progressBar = pb;

            ThreadMake tm = (new ThreadMake(ip, filePath, statusLabel, pb));
    }
    public SocketChannel createChannel(String ip, Label statusLabel){
            SocketChannel socketChannel = null;
            try{
                    socketChannel = SocketChannel.open();
                    socketChannel.connect(new InetSocketAddress(ip, 9999));
                    System.out.println("Connected..Now sending the file");
                    Platform.runLater(new Runnable() {
                        @Override public void run() {
                            statusLabel.setText("Status: Connected.. Now Sending File");
                        }
                    });
            }catch (IOException e){
                    e.printStackTrace();
                    statusLabel.setText("Status: Error occured");
            }
            return socketChannel;
    }

    public void sendFile(SocketChannel socketChannel, String filePath, Label statusLabel, ProgressBar progressBar)
    {
        RandomAccessFile aFile = null;
        try
        {
            File file = new File(filePath);
            aFile = new RandomAccessFile(file, "r");
            FileChannel inChannel = aFile.getChannel();
            ByteBuffer buffer = ByteBuffer.allocate(1024);

            buffer.put(file.getName().getBytes());
            buffer.flip();
            socketChannel.write(buffer);
            buffer.clear();
            long lSize = file.length();
            buffer.putLong(file.length());
            buffer.flip();
            socketChannel.write(buffer);
            buffer.clear();
            //loops will iterate (filesize/1000) times
            long lCount=0;
            double dPlus = (double)100/((double)lSize/(double)1000);
            double total=0;
            while (inChannel.read(buffer) > 0){
                Platform.runLater(new TestClass(total, progressBar));
                lCount += 1024;
                //System.out.print(total+"%, ");
                total += dPlus;
                buffer.flip();
                socketChannel.write(buffer);
                buffer.clear();
            }
            inChannel.close();
            buffer.clear();
            aFile.close();
            socketChannel.close();
            aFile.close();

            Platform.runLater(new Runnable(){
                @Override
                public void run() {
                    statusLabel.setText("Status: File sent ! ");
                }
            });
            System.out.println("End of file reached..");
        }catch (Exception e){
                e.printStackTrace();
        }
    }
}