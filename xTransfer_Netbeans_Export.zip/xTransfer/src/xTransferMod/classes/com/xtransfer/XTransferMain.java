/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.xtransfer;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author deval
 */
public class XTransferMain extends Application{
    public static void main(String[] args) {
        launch(args);
    } 
    @Override
    public void start(Stage primaryStage) throws Exception {
//        Button btn = new Button("Hello World");
//        StackPane root = new StackPane();
//        root.getChildren().add(btn);
//        Scene scene = new Scene(root, 600, 400);
//        stage.setScene(scene);
//        stage.setTitle("first app");
//        stage.show();
        try{
//            System.out.println("sdgbjskdg"+getClass().getResource("FXML.fxml"));
            Parent root = FXMLLoader.load(getClass().getResource("FXML.fxml"));
            
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("fxml.css").toExternalForm());

            primaryStage.setTitle("Peer to peer file transfer");
            primaryStage.setScene(scene);
            primaryStage.show();
        }catch(Exception e){
            System.out.println(e);
        }
    }
}
