package com.xtransfer;

import java.nio.*;
import java.net.*;
import java.util.*;
import java.lang.Math.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.ProgressBar;
class List implements Runnable{
	Thread t1;
	String d1;
	ArrayList<String> OnlineAddr = new ArrayList<String>();
	String[] addr;
        ProgressBar progressBar;
//	public static void main(String[] args) throws Exception{
//		(new List()).makeList();
//	}
        public static ArrayList<String> makeList(ProgressBar pb){
            
            System.out.println("---------------------------------");
		int port = 9999;
		//for 255.255.255.0 --- List(defaultNumbers)
		//for 255.255.0.0 --- List(defaultNumbers, 0-255)
		//in 255.0.0.0 -- it will take 18Hrs to detect total IPs....

		InetAddress localHost;
            try {
//                localHost=null;
                localHost = InetAddress.getByName(InetAddress.getLocalHost().getHostAddress());
//System.out.println("AFSNJA"+InetAddress.getLocalHost().getHostAddress());
            } catch (UnknownHostException ex) {
                Logger.getLogger(List.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
		String myIPArr[] = localHost.getHostAddress().split("\\.",-2);
		String myIP = "";
 		NetworkInterface networkInterface;
            try {
                System.out.println("MyHost: "+localHost);
                networkInterface = NetworkInterface.getByInetAddress(localHost);
                                System.out.println("zxf: "+networkInterface);

            } catch (SocketException ex) {
                Logger.getLogger(List.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
		int subNet = networkInterface.getInterfaceAddresses().get(1).getNetworkPrefixLength();
		List m=null;
               
		System.out.println("SUBNET="+subNet);
		System.out.println("IP="+localHost);
		
		StringBuilder extractedPrefix = extractPrefix(myIPArr, subNet);

		if(extractedPrefix.toString().equals("")){
                    System.out.println("Prefix is Empty");
                }else{
                    System.out.println("Extracted Prefix :: "+ extractedPrefix);
		}
		System.out.println("---------------------------------");

		if(subNet==24 || subNet > 32){
			System.out.println("\n------------------------------------\nWithin 1 second, result should be there\n");
			m = new List(extractedPrefix.toString(), pb);
		}else if(subNet==16 ||  subNet==64 || subNet == 128){
			System.out.println("You need to wait 255 seconds to detect all IPs that are online, as total IPs are 0-65025.");
			for(int i=0; i<255; i++){
                            try {
                                m = new List("192.168", i, pb);
                            } catch (Exception ex) {
                                Logger.getLogger(List.class.getName()).log(Level.SEVERE, null, ex);
                            }
			}
		}else{
			System.out.println("Unsupported SubnetMask");
			System.out.println("---------------------------------");
			return null;
		}
		
                try {
                    //time out is 3sec, if ping reply is not given within 3sec, then assume that it doesn't exist...
                    Thread.currentThread().sleep(3000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(List.class.getName()).log(Level.SEVERE, null, ex);
                }
		ArrayList<String> onlineAddr = m.getList();
                ArrayList<String> portIsActive = new ArrayList<String>();
		
		Socket skt;
		System.out.println("Addresses which are online now:");
		for(String str: onlineAddr){
                    System.out.println(str);
		}
                System.out.println("out");
		for(String str: onlineAddr){
			try{
                            skt = new Socket();
                            
                            skt.connect(new InetSocketAddress(str, port));
                            if(skt.isConnected()){
                                System.out.println("-------\nPort is active at Address: "+str);
                                portIsActive.add(str);
                                skt.close();
                            }
			}catch(Exception e){
                            System.out.println(str+"/"+port+"/"+e);
//				if(!e.toString().equals("java.net.ConnectException: Connection refused (Connection refused)")){
//					System.out.println(e);
//				}
			}
		}
		System.out.println("------------------------------------\n");
                return portIsActive;
        }
	List(String def, ProgressBar pb){
            progressBar = pb;
            try{
                addr = new String[256];
                d1 = def+".";

                for(int i=0; i<255; i++){
                    addr[i] = d1 + i;
                }
                System.out.println("Scanning Addresses");
                for(int i=0; i<255; i=i+0){	
                    t1 = new Thread(this, String.valueOf(i++));
                    progressBar.setProgress(progressBar.getProgress()+(255/100));
                    t1.start();
                }
            }catch(Exception e){
                    System.out.println(e);
            }
	}
	ArrayList<String> getList(){
		return OnlineAddr;	
	}
	List(String def, int level2, ProgressBar pb) throws Exception{
            progressBar = pb;
            addr = new String[256];
            d1 = def+"."+level2+".";
            for(int i=0; i<255; i++){
                progressBar.setProgress(progressBar.getProgress()+(255/1000));
                addr[i] = d1 + i;
            }
            for(int i=0; i<255; i=i+0){		
//                Thread.currentThread().sleep(3000);
                t1 = new Thread(this, String.valueOf(i++));
                t1.start();
            }
	}
	public void run(){
		try{
                    int num = Integer.parseInt(Thread.currentThread().getName());
                    if(InetAddress.getByName(addr[num]).isReachable(3000)){
                            OnlineAddr.add(addr[num]);
                    }
		}catch(Exception e){
			System.out.println(e);
		}	
	}
	static StringBuilder extractPrefix(String myIPArr[], int subNet){
		StringBuilder x = new StringBuilder(128);
		StringBuilder iPBinary = new StringBuilder(128);
		int myIPn;	
		int a=0,count=0;
		for(int i=0; i<4; i++){
                    myIPn = Integer.parseInt(myIPArr[i]);
                    if(myIPn==0){
                            iPBinary.append("00000000");
                    }
                    while(myIPn > 0){
                        a = myIPn % 2;
                        x = x.append(a);
                        myIPn = myIPn / 2;
                    }
                    count=0;
                    myIPn = 0;
                    x = x.reverse();

                    if(i==2 && x.length()<8 && x.length()!=0){
                            x.reverse();
                            int iTemp = (8-x.length());
                            while(iTemp != 0){
                                    x.append("0");
                                    iTemp--;
                            }
                            x.reverse();
                    }
                    iPBinary.append(x);
                    x.delete(0, x.length());
                }
                x.delete(0, x.length());
                for(int tempSubnet =0; tempSubnet < subNet; tempSubnet++){
                    x.append(iPBinary.charAt(tempSubnet));
                }
                count=8;
                byte flag=0;
                a=0;
                iPBinary.delete(0, iPBinary.length());
                for(int i=0; i<x.length(); i++){
                    count--;
                    try{
                        if(x.charAt(i) == '1'){
                                a += Math.pow(2,count);
                        }
                    }catch(Exception e){
                        System.out.println(i+","+e);
                    }
                    if(count==0 || (i == x.length()-1)){
                        if(flag==1){
                                iPBinary.append("."+a);
                        }else{
                                iPBinary.append(a);
                        }
                        flag=1;

                        a=0;
                        count=8;
                    }
                }
            return iPBinary;
	}
}