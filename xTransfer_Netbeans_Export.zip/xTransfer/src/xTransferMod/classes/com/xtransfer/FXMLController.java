package com.xtransfer;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.xtransfer.FileReceiver;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author deval
 */
public class FXMLController implements Initializable {

    public Button sendBtn;
    File selectedFile;
    public ListView<String> listView;
    public Button listButton, incr, decr;
    public Label statusLabel;
    public ProgressBar progressBar;
    
    @FXML
    public void rcvFile(ActionEvent aeEvent){
        FileReceiver fr = new FileReceiver();
        statusLabel.setText("Status: Receiver Started !");   
        fr.rcv(statusLabel, progressBar);
    }
    
    @FXML
    public void uploadFile(ActionEvent aeEvent){
       progressBar.setProgress(0);
        FileChooser fc = new FileChooser();
        selectedFile = fc.showOpenDialog(null);
        
        FileSender fs = new FileSender();
   
	fs.send(listView.getSelectionModel().getSelectedItem().toString(), selectedFile.toString(), statusLabel, progressBar);
        
        System.out.println("This is ip!"+listView.getSelectionModel().getSelectedItem().toString()+"");
    }
    
    public void incr(){
        progressBar.setProgress(progressBar.getProgress()+0.1);
    }
    public void decr(){
        progressBar.setProgress(progressBar.getProgress()-0.1);
    }
    @FXML
    public void listIP(ActionEvent aeEvent){
        ObservableList<String> items = FXCollections.observableArrayList();
        items.removeAll(items);
        
        items.addAll(List.makeList(progressBar));
        listView.setItems(items);
        listView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                sendBtn.setDisable(false);
            }
        });
    } 

    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
    }
    
}
