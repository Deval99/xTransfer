package com.xtransfer;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

class TestClass2 implements Runnable{
    double total;
    ProgressBar pb;
    TestClass2(double total, ProgressBar pb){
        this.total = total;
        this.pb = pb;
    }
    @Override
    public void run() {
        pb.setProgress((total/(double)100));
    }
    
}
public class FileReceiver{
    ProgressBar pb;
    Label lbl;
    ServerSocketChannel serverSocketChannelG;
    class innerClass implements Runnable{
        Thread thisThread;
        Label lbl;
        ProgressBar pb;
        innerClass(Label lbl, ProgressBar pb){
            this.lbl = lbl;
            this.pb = pb;
            thisThread = new Thread(this);
            thisThread.start();
        }
        public void run(){
            System.out.println("Receiver Started !");
            
            
            FileReceiver nioServer = new FileReceiver();
//            if(lbl == null){
//                System.out.println("IT IS NULL IN LINE38");
//            }
            SocketChannel socketChannel = nioServer.createServerSocketChannel(lbl);
            if(socketChannel != null){
                nioServer.readFileFromSocket(socketChannel, lbl, pb);
                try {
                    nioServer.serverSocketChannelG.close();
                } catch (IOException ex) {
                    Logger.getLogger(FileReceiver.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else{
                System.out.println("Not connected");
            }
        }
    }
    public void rcv(Label lbl, ProgressBar pb){
        this.lbl = lbl;
        this.pb = pb;
       
        innerClass ic = new innerClass(lbl, pb); 
    }
    public SocketChannel createServerSocketChannel(Label lbl){
            ServerSocketChannel serverSocketChannel;
            serverSocketChannel = null;
            SocketChannel socketChannel = null;
            try{
                    serverSocketChannel = ServerSocketChannel.open();
                    serverSocketChannel.socket().bind(new InetSocketAddress(9999));
                    socketChannel = serverSocketChannel.accept();
                    System.out.println("Connection established...." + socketChannel.getRemoteAddress());
                    Platform.runLater(new Runnable(){
                        public void run(){
                            lbl.setText("Status: Connection established...." );
                        }
                    });
                    
            }catch (IOException e){
                //bind exception, already in use
                Platform.runLater(new Runnable(){
                    @Override
                    public void run(){
                        lbl.setText("Status: Receiver Already Started !");
                    }
                });
            }
            serverSocketChannelG = serverSocketChannel;
            return socketChannel;
    }

    public void readFileFromSocket(SocketChannel socketChannel, Label lbl, ProgressBar pb){
        RandomAccessFile aFile = null;
        try{
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            StringBuffer fileName = new StringBuffer();
            socketChannel.read(buffer);
            buffer.flip();
            while(buffer.hasRemaining()){
                    fileName.append((char)buffer.get());
            }
            buffer.flip();
            buffer.clear();

            socketChannel.read(buffer);
            buffer.flip();
            long lSize = buffer.getLong();
            buffer.flip();
            buffer.clear();
            System.out.println("SIZE =  "+(float)lSize/(float)1000+"KB");
            String home = System.getProperty("user.home");
            System.out.println("Path is = "+home+"/Downloads/"+fileName);
            aFile = new RandomAccessFile(home+"/Downloads/"+fileName, "rw");
            FileChannel fileChannel = aFile.getChannel();
            
            long lCount=0;
            double dPlus = (double)100/((double)lSize/(double)1000);
            double total=0;
            
            while (socketChannel.read(buffer) > 0){
                Platform.runLater(new TestClass(total, pb));
                lCount += 1024;
                System.out.print(total+"%, ");
                total += dPlus;
                
                buffer.flip();
                fileChannel.write(buffer);
                buffer.clear();
            }
            Thread.sleep(1000);
            fileChannel.close();
            System.out.println("End of file reached..Closing channel");
            
            socketChannel.close();
        }catch (Exception e){
                System.out.println("116"+e);
        }
        try {
            serverSocketChannelG.close();
        } catch (IOException ex) {
            Logger.getLogger(FileReceiver.class.getName()).log(Level.SEVERE, null, ex);
        }
        Platform.runLater(new Runnable(){
             public void run(){
                 lbl.setText("Status: Receiver Restarted !");
                 pb.setProgress(1);
             }
        });
        
        (new FileReceiver()).rcv(lbl,pb);
    }    
}