/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

module xTransferMod {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.logging;
    requires java.base;
    
    opens com.xtransfer to javafx.fxml;
    exports com.xtransfer;
}
